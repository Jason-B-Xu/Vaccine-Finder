from django.urls import path
from . import views


urlpatterns = [
    path("", views.home, name = 'home'),
    path('find close', views.findClose, name = 'findclose'),
    path('email', views.emailRemind, name = '')
]
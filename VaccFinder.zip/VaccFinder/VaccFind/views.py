from django.shortcuts import render, HttpResponse
import requests, json, geopy
from geopy.geocoders import Nominatim

# Create your views here.

locate = Nominatim(user_agent="Test")

abbrevs = {
    "AL": "Alabama",
    "AK": "Alaska",
    "AZ": "Arizona",
    "AR": "Arkansas",
    "CA": "California",
    "CO": "Colorado",
    "CT": "Connecticut",
    "DE": "Delaware",
    "FL": "Florida",
    "GA": "Georgia",
    "HI": "Hawaii",
    "ID": "Idaho",
    "IL": "Illinois",
    "IN": "Indiana",
    "IA": "Iowa",
    "KS": "Kansas",
    "KY": "Kentucky",
    "LA": "Lousiana",
    "ME": "Maine",
    "MD": "Maryland",
    "MA": "Massachusetts",
    "MI": "Michigan",
    "MN": "Minnesota",
    "MS": "Mississippi",
    "MO": "Missouri",
    "MT": "Montana",
    "NE": "Nebraska",
    "NV": "Nevada",
    "NH": "New Hampshire",
    "NJ": "New Jersey",
    "NM": "New Mexico",
    "NY": "New York",
    "NC": "North Carolina",
    "ND": "North Dakota",
    "OH": "Ohio",
    "OK": "Oklahoma",
    "OR": "Oregon",
    "PA": "Pennsylvania",
    "RI": "Rhode Island",
    "SC": "South Carolina",
    "SD": "South Dakota",
    "TN": "Tennessee",
    "TX": "Texas",
    "UT": "Utah",
    "VT": "Vermont",
    "VA": "Virginia",
    "WA": "Washington",
    "WV": "West Virginia",
    "WI": "Wisconsin",
    "WY": "Wyoming"
}


def getCoords(cityName, stateName): #returns lat, long, address
    loc = locate.geocode(cityName + ',' + abbrevs[stateName] + ',' + "USA")
    return [loc.latitude, loc.longitude, loc.address]

def findSites(stateName): #Currently only finds CVS locations
    sites = set()

    url1 = "https://www.cvs.com/immunizations/covid-19-vaccine.vaccine-status." + stateName + ".json?vaccineinfo"
    for x in json.loads(requests.request("GET", url1, headers={
        'referer': 'https://www.cvs.com/immunizations/covid-19-vaccine'}).text)['responsePayloadData']['data'][stateName]:
        if x['status'] != 'Fully Booked':
            sites.add(x['city'])
    return sites

def findClosest(yourCoords, sites, state): #Need to change to convery lat/long to miles before comparing
    closest = ""
    minDist = 999999

    for site in sites:
        siteCoords = getCoords(site, state)
        dist = ((siteCoords[0] - yourCoords[0]) ** 2 + (siteCoords[1] - yourCoords[1]) ** 2) ** 0.5
        if dist < minDist:
            closest = site
            minDist = dist
    return [closest, minDist]






def home(request):
    return render(request, 'home.html', {})

def findClose(request):
    cityname = request.GET['city']
    statename = request.GET['state'].upper()
    coords = getCoords(cityname, statename)
    sites = findSites(statename)
    closest, dist = findClosest(coords, sites, statename)
    dist = int(float(dist) * 55)
    return render(request, 'result.html', {'result':closest, 'distance':dist, 'location':coords[2]})

def emailRemind(request):
    emailadd = request.GET['email']
    maxmiles = request.GET['miles']
    return render(request, 'emailconfirm.html', {'email':emailadd, 'miles':maxmiles})